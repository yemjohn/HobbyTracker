const mongoose = require("mongoose");
const { resetWatchers } = require("nodemon/lib/monitor/watch");
const Team = mongoose.model(process.env.TEAM_MODEL);


module.exports.getAll = function (req, res) {
  const teamId = req.params.teamId;
  if (req == null) {
    return res.status(404).send({ message: "Nothing to display" });
  }
  console.log("This is the function for diplaying all teams");
  Team.findById(teamId)
    .select("players")
    .exec(function (err, teams) {
      if (err) {
        console.log("Internal Error is causing problem");
        return res
          .status(500)
          .json({ message: "May be the DB is empty and bugging you a lot" });
      }
      console.log("Found publishers");
      res.status(200).json(teams.players);
    });
};

module.exports.getOne = function (req, res) {
  const teamId = req.params.teamId;
  const playerId = req.params.playerId;
  if (!req.body) {
    console.log("No single game is fetched!");
    return res.status(404).send({ message: "No single game is fetched!" });
  }

  Team.findById(teamId).exec(function (err, team) {
    if (err) {
      console.log("Internal Error is causing problem");
      return res
        .status(500)
        .send({ message: "May be the DB is empty and bugging you a lot" });
    }
    console.log("A team selected by getOne");
    res.status(200).json(team.players.id(playerId));
  });
};

module.exports.addOne = function (req, res) {
  if (!req) {
    console.log("Where and what to be updated are not defined");
    return res
      .status(404)
      .json({ msg: "Where and what to be updated are not defined" });
  }
  const teamId = req.params.teamId;
  Team.findByIdAndUpdate(
    teamId,
    { $push: { players: req.body } },
    function (err, teamAdded) {
      if (err) {
        console.log("Adding player failed for some reason", err);
        res.status(err.status).send({ error: err.message });
      } else {
        // teamAdded.players.push({name: req.body.name, age: req.body.age});
        console.log("Player Added", teamAdded.players);

        res.status(201).json(teamAdded);
      }
    }
  );
};

module.exports.updateOne = function (req, res) {
  const teamId = req.params.teamId;
  const playerId = req.params.playerId;
  if (!req) {
    console.log("Where and what to be updated are not defined");
    return res
      .status(404)
      .json({ msg: "Where and what to be updated are not defined" });
  }
  Team.findOneAndUpdate(
    { _id: teamId, "players._id": playerId },
    {
      $set: {
        // "players.$._id": playerId,
        "players.$.name": req.body.name,
        "players.$.age": req.body.age,
      },
    },
    function (err, editPlayer) {
      if (err) {
        console.log("Error while updating players");
        return res
          .status(404)
          .json({
            msg: "Error while adding players in addOne player function",
          });
      }
      console.log("Player is added");
      res.status(201).json({ message: "Edited Succcesfully" });
    }
  );
};

module.exports.deleteOne = function (req, res) {
  const teamId = req.params.teamId;
  const playerId = req.params.playerId;
  if (!req) {
    console.log("Where and what to be deleted is not defined");
    return res
      .status(404)
      .json({ msg: "Where and what to be deleted is not defined" });
  }
  Team.findOneAndUpdate(
    { _id: teamId },
    { $pull: { players: { _id: playerId } } },
    {new: true},
    function (err) {
      if (err) {
        console.log("Error while updating players");
        return res.status(404).json({ msg: "Error while deleteing player" });
      }
      console.log("Player is deleted");
      res.status(201).json({ message: "Deleted Succcesfully" });
    }
  );
};
